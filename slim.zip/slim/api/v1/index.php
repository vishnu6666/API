<?php
    require_once '../include/DbHandler.php';
    require_once '../include/PassHash.php';
    require '.././libs/Slim/Slim.php';

        \Slim\Slim::registerAutoloader();

        $app = new \Slim\Slim();

        // User id from db - Global Variable
        $user_id = NULL;
        function verifyRequiredParams($required_fields)
        {
            $error = false;
            $error_fields = "";
            $request_params = array();
            $request_params = $_REQUEST;


        // Handling PUT request params
        if ($_SERVER['REQUEST_METHOD'] == 'PUT') 
        {
            $app = \Slim\Slim::getInstance();
            parse_str($app->request()->getBody(), $request_params);
        }

        foreach ($required_fields as $field)
        {
            if (!isset($request_params[$field]) || strlen(trim($request_params[$field])) <= 0) 
            {
                $error = true;
                $error_fields .= $field . ', ';
            }
        }

        if ($error) 
        {
            // Required field(s) are missing or empty
            // echo error json and stop the app
            $response = array();
            $app = \Slim\Slim::getInstance();
            $response["error"] = true;
            $response["message"] = 'Required field(s) ' . substr($error_fields, 0, -2) . ' is missing or empty';
            echoRespnse(200, $response);
            $app->stop();
        }
    }
    function authenticate(\Slim\Route $route)
    {
        // Getting request headers
        $headers = apache_request_headers();
        $response = array();
        $app = \Slim\Slim::getInstance();

        // Verifying Authorization Header
        if (isset($headers['Authorization'])) 
        {
            $db = new DbHandler();

            // get the api key
            $api_key = $headers['Authorization'];
            // validating api key
            if (!$db->isValidApiKey($api_key)) 
            {
                // api key is not present in users table
                $response["error"] = true;
                $response["message"] = "Access Denied. Invalid Api key";
                echoRespnse(200, $response);
                $app->stop();
            } 
            else 
            {
                global $user_id;
                // get user primary key id
                $user = $db->getUserId($api_key);
                if ($user != NULL)
                    $user_id = $user["id"];
            }
        } 
        else 
        {
            // api key is missing in header
            $response["error"] = true;
            $response["message"] = "Api key is misssing";
            echoRespnse(200, $response);
            $app->stop();
        }
    }

    //check login
    $app->post('/login',function () use ($app)
    {
        verifyRequiredParams(array('email', 'password'));

        // reading post params
        $email = $app->request()->post('email');
        $password = $app->request()->post('password');
        $response = array();

        $db = new DbHandler();
        // check for correct email and password
            if ($db->checkMyLogin($email, $password)) 
            {
                // get the user by email
                $user = $db->getUserByEmail($email);
                //print_r($user);exit;
                if ($user != NULL) 
                {
                    $response["error"] = false;
                    $response['firstname'] = $user['firstname'];   
                    $response['email'] = $user['email'];
                    $response['apiKey'] = $user['api_key'];
                    //$response['createdAt'] = $user['created_at'];
                } 
                else 
                {
                    // unknown error occurred
                    $response['error'] = true;
                    $response['message'] = "login successful";
                }
            } 
            else 
            {
                // user credentials are wrong
                $response['error'] = true;
                $response['message'] = 'Login failed. Incorrect User';
            }

                echoRespnse(200, $response);
    });

    //register user or insert user
    $app->post('/register', function () use ($app) 
    {
        // check for required params
        verifyRequiredParams(array('email','password','firstname','lastname','gender','education','hobbies'));

            $email = $app->request->post('email');
            $password = $app->request->post('password');
            $firstname = $app->request->post('firstname');
            $lastname = $app->request->post('lastname');
            $gender = $app->request->post('gender');
            $education = $app->request->post('education');
            $hobbies = $app->request->post('hobbies');
            $profile_pic = $app->request()->post('profile_pic');

            $db = new DbHandler();
            $response = array();

   
            $base_url = $app->request->geturl() . "/slim/upload/";
            $file_name = '';
            if(isset($_FILES['profile_pic'])) 
            {
                if($file_name = image_upload($_FILES['profile_pic'])) 
                {

                    $res = $db->createUser($email,$password,$firstname,$lastname,$gender,$education,$hobbies,$file_name);

                    if ($res == false)
                    {

                        $response["message"] = "Failed to Insert";
                        echoRespnse(200, $response);   
                    } 
                    else 
                    {
                        $response["error"] = true;
                        $response["message"] = "Success";
                        echoRespnse(200, $response);
                    }
                }
            }  
    });

    //image upload
    function image_upload($file = array())
    {
        $app = \Slim\Slim::getInstance();
        $dir = dirname(dirname(dirname(__FILE__))) . "/upload/";

        $errors = array();

        $path_parts = pathinfo($_FILES["profile_pic"]["name"]);
        $file_name = $path_parts['filename'].'_'.time().'.'.$path_parts['extension'];

        $file_size = $file['size'];
        $file_tmp = $file['tmp_name'];
        $file_type = $file['type'];

        $explode = explode('.', $file_name);
        $file_ext = strtolower(end($explode));
        $response = array();

        if ($file_size > 5097152)
        {
            $response["error"] = true;
            $response["message"] = "file size must be exactely 2 MB";
            echoRespnse(200,$response);
            $app->stop();
        }

        if (empty($errors) == true) 
        {
            move_uploaded_file($file_tmp, $dir . $file_name);
            return $file_name;
        }
    }

    //get response 
    function echoRespnse($status_code, $response)
    {
        $app = \Slim\Slim::getInstance();
        // Http response code
        $app->status($status_code);

        // setting response content type to json
        $app->contentType('application/json');
        echo json_encode($response);
    }

    //view result
    $app->get('/view', function () use ($app) 
    {
        // check for required params
        $response = array();
        $db = new DbHandler();
        $result = $db->view();

        $response["error"] = false;
        $response["row"] = array();

        while ($row = mysqli_fetch_assoc($result)) 
        {
            $tmp = array();
            $tmp["id"] = $row["id"];
            $tmp["email"] = $row["email"];
            $tmp["password"] = $row["password"];
            $tmp["firstname"] = $row["firstname"];
            $tmp["lastname"] = $row["lastname"];
            $tmp["gender"] = $row["gender"];
            $tmp["education"] = $row["education"];
            $tmp["hobbies"] = $row["hobbies"];
            $tmp["profile_pic"] = $row["profile_pic"];
            array_push($response["row"],$tmp);
        }

        if ($result->num_rows > 0) 
        {
            echoRespnse(200, $response);
        } 
        else 
        {
            $responses['error'] = true;
            $responses['message'] = 'No Data Found';
            echoRespnse(200, $responses);
        }
    });

    //delete record
    $app->delete('/delete/:id', function ($id) use ($app) 
    {

        $response =array();
        $db = new DbHandler();

        $res = $db->delete($id);
        if($res > 0)
        {
            $response['error'] = false;
            $response['message'] = "deleted successfully";
        } 
        else 
        {
            $response['error'] = true;
            $response['message'] = "An error occured. Plz try again";
        }
        echoRespnse(200, $response);
    });

    //update record
    $app->post('/edit/:id',function ($id) use ($app) 
    {
     
        verifyRequiredParams(array('email','password','firstname','lastname','gender','education','hobbies'));

    
        $email = $app->request->post('email');
        $password = $app->request->post('password');
        $firstname = $app->request->post('firstname');
        $lastname = $app->request->post('lastname');
        $gender = $app->request->post('gender');
        $education = $app->request->post('education');
        $hobbies = $app->request->post('hobbies');
        $file_name = $app->request()->post('profile_pic');

   
        $response = array();
        $db = new DbHandler();

        $base_url = $app->request->geturl() . "/Slime/upload/";
        $file_name = '';
        if(isset($_FILES['profile_pic'])) 
        {
            if($file_name = image_upload($_FILES['profile_pic'])) 
            {

                $res = $db->edit($email,$password,$firstname,$lastname,$gender,$education,$hobbies,$file_name,$id); 

                if ($res) 
                {
                        $response['error'] = false;
                        $response['message'] = "updated successfully";
                        echoRespnse(200, $response);
                } 
                else 
                {
                        $response['error'] = true;
                        $response['message'] = "failed to update";
                        echoRespnse(200, $response);
                }
        }       }        
    });
    $app->run();
?>