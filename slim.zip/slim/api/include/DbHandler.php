<?php

/**
 * Class to handle all db operations
 * This class will have CRUD methods for database tables
 *
 * @author Milan Soni
 */
class DbHandler
{

    /** @var mysqli */
    private $conn;

    function __construct()
    {
        require_once dirname(__FILE__) . '/DbConnect.php';
        // opening db connection
        $db = new DbConnect();
        $this->conn = $db->connect();
    }

    /* ------------- `users` table method ------------------ */


    

    /**
     * Checking user login
     * @param String $email User login email id
     * @param String $password User login password
     * @return boolean User login status success/fail
     */



  // check login
  public function checkMyLogin($email,$password)
  {
        $sql = "select * from tbl_slim where email = '$email' and password = '$password'";
        $data = mysqli_query($this->conn,$sql);
        if(mysqli_affected_rows($this->conn)>0)
        {
            return true;
        }
        else
        {
            return false;
        }
  }


    public function getUserByEmail($email)
    {
        $sql = "SELECT first_name,email,api_key FROM tbl_slim WHERE email = '" . $email . "'";
        $result = mysqli_query($this->conn, $sql);
      if ($result)
        {
            return $row = mysqli_fetch_assoc($result);
        } 
        else 
        {
            return NULL;
        }
    }


    //create user or insert user
    public function createUser($email,$password,$firstname, $lastname,$gender,$education,$hobbies,$file_name)
    {
        $api_key=$this->generateApiKey();

      echo  $sql=
                "INSERT INTO `tbl_slim`
                (`email`, `password`, `firstname`, `lastname`, `gender`, `education`, `hobbies`,`profile_pic`, `api_key`)
                VALUES ('$email','$password','$firstname','$lastname','$gender','$education','$hobbies','$file_name','$api_key')";

              if (mysqli_query($this->conn, $sql))
              {
                return true;
              } 
              else 
              {
                return false;
              }
    }

    //view record
    public function view()
    {
        $sql = "SELECT * FROM tbl_slim";
        $result = mysqli_query($this->conn, $sql);
        if ($result) 
        {
            return $result;
        } 
        else 
        {
            return NULL;
        }
    }

    //delete record
    public function delete($id)
    {
        $sql = "DELETE FROM tbl_slim WHERE id=$id";

        if(mysqli_query($this->conn, $sql))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    //edit or update record
    public function edit($email,$password,$firstname,$lastname,$gender,$education,$hobbies,$file_name,$id)

    {


     echo $sql=
              "UPDATE `tbl_slim`
                   SET `email`='$email',
                   `password`='$password',
                   `firstname`='$firstname',
                   `lastname`='$lastname',
                   `gender`='$gender',
                   `education`='$education',
                   `hobbies`='$hobbies',
                   `profile_pic`='$file_name'
                    WHERE id='$id'";
       
                  $result = mysqli_query($this->conn,$sql);
                  if($result)
                  {
                    return true;
                  }
                  else
                  {
                    return false;
                  }
    }

    /**
     * Generating random Unique MD5 String for user Api key
     */
    private function generateApiKey()
    {
        return md5(uniqid(rand(), true));
    }
}
?>